package bief_03;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Personne[] personnes = new Personne[2];
		
		Medecin[] Medecin = new Medecin[1];
		Opticienne[] Opticienne = new Opticienne[1];
		
		Medecin[0] = new Medecin("Maher",31);
		Opticienne[0] = new Opticienne("Iman",33);
		
		for(int i = 0; i < Medecin.length; i++) {
			Medecin[i].afficher();
		}
		
		for(int i = 0; i < Opticienne.length; i++) {
			Opticienne[i].afficherop();
		}

		

		/*Medecin medecin = new Medecin("Maher" ,31);
		medecin.afficher();
		
		Opticienne opt= new Opticienne("Iman",33);
		opt.afficherop();*/
		
 
	}

}
