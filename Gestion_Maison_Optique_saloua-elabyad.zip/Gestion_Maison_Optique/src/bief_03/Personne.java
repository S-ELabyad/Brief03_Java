package bief_03;

public class Personne {
	
	private String Nom;
	private double Age;
	
	
	
	public Personne(String Nom, double Age) {
		this.Nom=Nom;
		this.Age=Age;

	}
	
	
	public String getNom() {
		return Nom;
	}
	public void setNom(String Nom) {
		this.Nom = Nom;
	}


	public double getAge() {
		return Age;
	}
	public void setAge(double Age) {
		this.Age = Age;
	}
	
	public void afficher() {
        System.out.println("Je suis " +getNom()+" j'ai " +getAge()+" ans et je travaille en tant que m�decin  !");	
	}

}
