package bief_03;

public class Medecin extends Personne{
	
	Medecin( String Nom,double Age) {
		super(Nom, Age);
	}
	
	
	public void afficher() {
        System.out.println("Je suis " +getNom()+" j'ai " +getAge()+" ans et je travaille en tant que m�decin  !");	
	}
	


}
