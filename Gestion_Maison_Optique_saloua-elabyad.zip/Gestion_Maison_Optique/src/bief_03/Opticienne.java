package bief_03;

public class Opticienne extends Personne {

	Opticienne( String Nom,double Age) {
		super(Nom, Age);
	}
	
	public void afficherop() {
        System.out.println("Je suis " +getNom()+"j'ai " +getAge()+" ans et je travaille en tant que opticienne  !");	
	}
	
}
